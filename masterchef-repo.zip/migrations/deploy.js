const { ethers } = require("hardhat");

async function main() {
  const rewardTokenAddress = "YOUR_BOOM_TOKEN_ADDRESS";
  const lpTokenAddress = "YOUR_LP_TOKEN_ADDRESS";
  const rewardPerBlock = ethers.utils.parseEther("0.05"); // Replace with your reward rate
  const startBlock = 1000; // Replace with your start block
  const endBlock = 2000; // Replace with your end block

  const MasterChef = await ethers.getContractFactory("MasterChef");
  const masterChef = await MasterChef.deploy(
    rewardTokenAddress,
    lpTokenAddress,
    rewardPerBlock,
    startBlock,
    endBlock
  );

  await masterChef.deployed();
  console.log("MasterChef deployed to:", masterChef.address);
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error);
    process.exit(1);
  });
