# MasterChef Repository

This repository contains the MasterChef contract and related files for BOOM token's liquidity provider (LP) rewards program.

## Features
- Stake LP tokens to earn BOOM rewards.
- Customizable reward rates and durations.

## Setup

### Prerequisites
- Node.js and npm installed
- Hardhat installed globally: `npm install --global hardhat`

### Installation
1. Clone this repository:
   ```bash
   git clone https://github.com/YOUR_USERNAME/masterchef-repo.git
   cd masterchef-repo
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

### Deployment
1. Update `migrations/deploy.js` with your token addresses and parameters.
2. Deploy to the Binance Smart Chain testnet:
   ```bash
   npx hardhat run migrations/deploy.js --network testnet
   ```

### Testing
Run the tests to ensure everything works as expected:
```bash
npx hardhat test
```

## License
MIT
