const { expect } = require("chai");
const { ethers } = require("hardhat");

describe("MasterChef", function () {
  it("Should deploy and set the correct parameters", async function () {
    const [owner, user] = await ethers.getSigners();

    const BOOM = await ethers.getContractFactory("ERC20Mock");
    const boomToken = await BOOM.deploy("BOOM Token", "BOOM", 18, ethers.utils.parseEther("1000000"));

    const LP = await ethers.getContractFactory("ERC20Mock");
    const lpToken = await LP.deploy("LP Token", "LP", 18, ethers.utils.parseEther("1000000"));

    const MasterChef = await ethers.getContractFactory("MasterChef");
    const rewardPerBlock = ethers.utils.parseEther("0.05");
    const startBlock = 1000;
    const endBlock = 2000;

    const masterChef = await MasterChef.deploy(
      boomToken.address,
      lpToken.address,
      rewardPerBlock,
      startBlock,
      endBlock
    );

    await masterChef.deployed();

    expect(await masterChef.rewardToken()).to.equal(boomToken.address);
    expect(await masterChef.lpToken()).to.equal(lpToken.address);
    expect(await masterChef.rewardPerBlock()).to.equal(rewardPerBlock);
  });
});
